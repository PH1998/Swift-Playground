# swift-timer-demo
The complete project files from a tutorial I made: "Build a Count Down Timer with Swift 3.0."

See the tutorial at https://medium.com/@jen.sip/build-an-stopwatch-with-swift-3-0-c7040818a10f#.sbfbadbur

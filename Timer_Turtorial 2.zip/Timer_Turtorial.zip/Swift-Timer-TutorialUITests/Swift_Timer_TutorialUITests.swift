
import XCTest

class Swift_Timer_TutorialUITests: XCTestCase {
        
    override func setUp() {
        super.setUp()
        
        
        continueAfterFailure = false
        
        XCUIApplication().launch()

       
    }
    
    override func tearDown() {
                super.tearDown()
    }
    
    func testExample() {
           }
    
}
